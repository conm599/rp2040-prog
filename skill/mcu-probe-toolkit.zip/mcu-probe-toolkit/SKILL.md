---
name: mcu-probe-toolkit
description: 把 RP2040（Pico 形态）当烧录器或调试器使用时，选固件、接线、烧录、排错的全套能力。本技能应在此类对话中主动加载：涉及 debugprobe、DapperMime、yapicoprobe、pico_rvd、FiXPro、MioLink、pico-uart-bridge 等 RP2040 探针固件，SWD / SWIO / UPDI / SPI Flash 烧录，pyOCD 或 OpenOCD 命令行操作，BOOT0 与串口 ISP 时序，CH340 无响应，UF2 拖拽刷写，以及 STM32F103 兼容片刷不进去等问题时使用。
agent_created: true
---

# RP2040 探针与 MCU 烧录

## 能力范围

把一块 RP2040 变成调试器、SPI Flash 编程器、单线烧录器或 USB-TTL，并用它完成 MCU 的探测、烧录与排错。具体提供四件事：

| 能力 | 产出 |
|---|---|
| **选固件** | 按目标芯片和协议决定刷哪个 uf2，以及哪些固件互不兼容 |
| **接线** | SWD / SWIO / UPDI / SPI / UART 各自的引脚定义与共地要求 |
| **烧录** | pyOCD 命令行读芯片、擦除、写入、回读校验 |
| **排错** | 分层判断「刷不进去」：链路层、配置层、器件层、协议层 |

## 触发场景

以下任意一类问题出现时加载本技能：

- RP2040 / Pico 刷成调试器、探针、烧录器、TTL 桥
- SWD 接线、BOOT0、Connect under reset、读保护
- pyOCD / OpenOCD / GDB server 命令行操作
- CH340 / CP2102 不工作、串口 ISP 超时、握手收不到字节
- STM32F103 及兼容片（GD32 / CS32 / HK32 / APM32 / CKS32）烧录失败
- UF2 拖拽刷写、family ID、Pico 2 与 Pico 固件能否互刷

## 工作方式

按这个顺序推进，不要跳步：

1. **确定目标芯片与协议** → 查 `references/firmware-matrix.md` 选固件。私有协议（WCH SWIO、AVR UPDI）必须用专用固件，标准 CMSIS-DAP 无法兼容，这是电气层差异，不是软件配置问题。
2. **刷探针** → BOOTSEL + 拖 uf2。RP2040 的 bootloader 固化在 ROM 里，刷错不会变砖。
3. **接线** → SWD 直连同名对同名，串口才需要 TX↔RX 交叉。认丝印不认位置。
4. **先读再写** → `scripts/probe.py` 确认链路与芯片参数，再 `scripts/flash.py` 烧录。
5. **失败则分层排查** → `references/stm32f103-troubleshooting.md` 按命中率排序。

不要凭空追问探针固件版本和芯片参数——先跑探测脚本拿实测值，比问更快也更准。

## 默认参数假设

以下是对这一大类硬件的实测结论，作为起始值使用，实际以 `probe.py` 读回的值为准：

| 参数 | 取值 | 依据 |
|---|---|---|
| F103 兼容片 Flash 容量 | **128 KB** | 读 `0x1FFFF7E0` 确认；标称 C8T6 若报 64 才是正品 |
| F103 兼容片页大小 | **1 KB** | ST 官方的 `STM32F10x_128.FLM` 按 2KB 页写，用在这类芯片上写入末尾必然校验失败 |
| SWD 时钟 | 1 MHz 起，连不上降到 100 kHz | 杜邦线长、干扰大时 1MHz 都不稳 |
| SWD 引脚（debugprobe 系） | GP2→SWCLK、GP3→SWDIO、GND→GND | 3V3 可选，两路供电时不要接 |

## 关键判据

判断芯片死活看这三项，不看 UID 内容：

| 读数 | 含义 |
|---|---|
| `DPIDR = 0x1BA01477` | 调试端口活着，SWD 链路成立 |
| `CPUID = 0x412FC230` | Cortex-M3 在跑 |
| HALT 成功 | 内核可停，可烧录 |

ID 读回全 `FF` 是「没读到」（没共地、没供电、线接反、时钟太快），不是芯片坏；全 `00` 才是「读到了，内容为空」。

## 三条铁律

1. **SWD 直连，串口交叉。** 两者混用是最高频的接线错误。
2. **能上 SWD 就不用串口 ISP。** 串口 ISP 要目标芯片的 bootloader 主动配合，芯片跑飞或 bootloader 坏了就彻底没路。
3. **BOOT0 只在串口 ISP 时拨到 1，刷完必须拨回 0；用 SWD 时固定为 0。**

## 脚本

依赖 `pip install pyocd keystone-engine`，需要接一个 CMSIS-DAP 探针。

```bash
python scripts/probe.py --uid-region       # 读 DPIDR / CPUID / DBGMCU / Flash / UID
python scripts/blink.py                    # 生成最小闪灯固件，验证链路
python scripts/flash.py app.hex            # 按 128KB + 1KB 页烧录并回读校验
python scripts/flash.py app.bin --addr 0x08000000
```

`probe.py` 和 `flash.py` 内置了 F103 兼容片的 target 定义（128KB / 1KB 页），不要换回 pyOCD 内置的 F103RC（2KB 页）。

## 参考资料

- 八个 RP2040 固件的用途、VID:PID、接线差异与实测表现 → `references/firmware-matrix.md`
- STM32F103 刷不进去的完整成因与排查顺序 → `references/stm32f103-troubleshooting.md`
- UF2 块结构、family ID、bin→uf2 转换、MioLink 自编译 → `references/rp2040-uf2.md`

## 外部资源

- 固件合集与接线说明：https://conm599.github.io/rp2040-prog/
- 源码仓库：https://github.com/conm599/rp2040-prog
