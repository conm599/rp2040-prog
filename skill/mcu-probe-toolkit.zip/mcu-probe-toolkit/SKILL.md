---
name: mcu-probe-toolkit
description: 处理 RP2040 当烧录器/调试器（CMSIS-DAP、Black Magic、SPI Flash 编程器、USB-TTL、CH32 SWIO）以及 STM32F103 兼容片烧录排错时使用。本技能应在此类对话中主动加载：用户提到 debugprobe、DapperMime、yapicoprobe、pico_rvd、FiXPro、MioLink、pico-uart-bridge、RP2040 探针、SWD 接线、pyOCD、BOOT0、C8T6 刷不进去、CH340 无响应、串口 ISP 超时、UF2 拖拽刷写等问题时使用。
agent_created: true
---

# MCU 烧录器与探针工具箱

## 这个技能解决什么

用户手上有一套已经跑通的硬件组合：一块几块钱的 RP2040 刷成调试器，通过 SWD 烧录一块 STM32 兼容片。过去这些信息每次都要靠用户重新解释一遍，本技能把它固化成可复用的环境知识、排错表和脚本，避免重复问答。

**加载后不要重新问「你手上是什么板子」「用什么下载器」**——先按下面的环境基线工作，只在实测结果与基线冲突时才追问。

## 环境基线（已实测确认，可直接采信）

| 项 | 实际值 |
|---|---|
| 探针 | RP2040（Pico 形态），当前固件 debugprobe v2.3.1 |
| 探针 USB | `2E8A:000C` CMSIS-DAP v2 + 虚拟串口 COM14（透传 GP4/GP5） |
| 目标芯片 | 标称 STM32F103C8T6，实为兼容片：Flash 报 **128KB**、96 位 UID 全 0 |
| 目标 Flash 参数 | **128KB 容量 + 1KB 页**（不是正品 C8 的 64KB，也不是 ST 官方的 2KB 页） |
| 目标状态 | 已烧入双灯闪灯固件，PC13 + PB0 反相闪烁，SWD 可连可停 |
| 已废弃器件 | CH340 模块 TX 引脚已烧坏（拔掉所有线后 TX 灯常亮），不要再建议走串口 ISP |

## 三条铁律

1. **SWD 是直连，不是交叉。** GP2→SWCLK、GP3→SWDIO、GND→GND、3V3 可选。串口才需要 TX↔RX 交叉，两者经常被混淆。
2. **烧这颗芯片按 128KB + 1KB 页配置。** 用 ST 官方的 2KB 页算法文件会在写入末尾校验失败，这是当初「怎么刷都刷不进去」的真正技术原因之一。
3. **BOOT0 固定在 0。** SWD 绕过启动模式选择，不需要拨到 1。BOOT0=1 会让芯片进 bootloader 而不跑用户程序，表现为「单独上电不闪」。

## 标准工作流

优先级：先读，再写，最后才怀疑硬件。

```bash
# 1. 确认探针在
pyocd list

# 2. 读芯片（DPIDR / CPUID / DBGMCU / Flash / UID / 核心状态）
python scripts/probe.py

# 3. 烧录（hex 或 bin 都支持，自动按 128KB/1KB 页处理并回读校验）
python scripts/flash.py firmware.hex
python scripts/flash.py firmware.bin --addr 0x08000000

# 4. 无固件可烧时，用最小闪灯固件验证链路
python scripts/blink.py && python scripts/flash.py blink.bin
```

脚本依赖 `pyocd` 与 `keystone-engine`（仅 blink.py 需要）。解释器要用装了这些包的 Python；本机是 `C:/Users/naxid/AppData/Local/Programs/Python/Python310/python.exe`，系统里的 `python` 是 3.13 且没有这些包。

## 判断芯片死活的正确标准

不要看 UID 内容，看这三样：

| 读数 | 说明 |
|---|---|
| `DPIDR = 0x1BA01477` | 调试端口活着，SWD 链路成立 |
| `CPUID = 0x412FC230` | 内核在跑（Cortex-M3） |
| HALT 成功 | 能把内核停下来，说明可烧录 |

**常见误判**：ID 读出来全是 `FF` 不代表芯片坏，那是「没读到」——线没共地、目标没供电、SWDIO/SWCLK 接反、时钟太快、芯片被复位按住。全 `00` 才是「读到了，内容为空」。

## 详细资料

- 八个 RP2040 固件的用途、VID:PID、实测记录、接线差异 → `references/firmware-matrix.md`
- STM32F103 烧录失败的全部成因与排查顺序（BOOT0、串口 ISP、读保护、兼容片）→ `references/stm32f103-troubleshooting.md`
- UF2 格式、family ID、拖拽刷写与 BOOTSEL 的机制 → `references/rp2040-uf2.md`

## 相关外部资源

- 固件合集站点：https://conm599.github.io/rp2040-prog/
- 源码仓库：https://github.com/conm599/rp2040-prog
