# RP2040 固件矩阵（含实机验证结果）

所有固件均为 `family 0xE48BFF56`（RP2040），只有一个例外见末尾。

## 已验证可用

### debugprobe（树莓派官方，首选）
- 版本：v2.3.1　文件：`debugprobe_on_pico.uf2`　105 KB
- 协议：CMSIS-DAP v2 / SWD
- USB：`2E8A:000C`，同时枚举 CMSIS-DAP 接口 + 一个 CDC 串口（透传 **GP4=TX / GP5=RX**）
- 覆盖：STM32、GD32、APM32、MM32、nRF52 等所有 Cortex-M
- 工具：pyOCD、OpenOCD、Keil、CubeProgrammer
- 特性：AutoBaud（把波特率设成特殊值可自动嗅探目标波特率）
- **默认选择**。既是调试器又是 TTL，一个设备两用，比山寨 ST-Link 强。

### DapperMime
- 文件：`DapperMime.uf2`
- 协议：CMSIS-DAP v1 / HID
- USB：`CAFE:4005`，pyOCD 里显示为 `TinyUSB RP2040 CMSIS-DAP`
- 用途：v1/HID 免驱模式，Keil 老版本或某些不认 v2 的软件用它救场
- 注意：设备名不是它自己的名字，按 VID:PID 认

### yapicoprobe
- 版本：v2.02.06　文件：`yapicoprobe.uf2`
- 协议：CMSIS-DAP 增强版，带 SWO 和双串口
- 特性：启动后额外挂一个只读 U 盘，卷标 `YAPicoprobe`，内含 `CURRENT.UF2`（目标芯片 flash 当前镜像）、`RAM.UF2`。把 uf2 拖进那个盘就等于刷目标芯片
- 注意：该盘的 `INFO_UF2.TXT` 会被脚本误认为 bootloader 盘，判定时必须认卷标 `RPI-RP2`

### pico_rvd
- 版本：v0.1　文件：`pico_rvd.uf2`
- 协议：**WCH SWIO 单线**（不是 SWD）
- USB：`2E8A:000A`（pico-sdk 默认 CDC）
- 覆盖：CH32V003 等 WCH RISC-V 芯片
- 接线：GP4，需 1kΩ 上拉
- 为什么必须是专用固件：SWIO 把时钟编码进数据波形做自同步，物理层只有一根线，电气协议与 SWD 完全不同，任何标准调试器固件都无法兼容。主机侧用 `wlink` 或 `minichlink`

### FiXPro
- 版本：v2.1.0　文件：`FiXPro_v2.1.0.uf2`
- 协议：SPI / I²C / SWD / JTAG / UPDI / 1-Wire
- USB：`2E8A:000A` CDC
- 引脚：SPI 用 GP16(MISO)/GP17(CS)/GP18(SCK)/GP19(MOSI)；I²C 用 GP20(SDA)/GP21(SCL)
- 操作方式：仓库里的 `docs/index.html` 通过 **Web Serial** 连接，纯静态页，无需服务器
- 文本协议：`PING`→`CAFE`、`VERSION`、`CAPS`、`SPI_ID`、`I2C_SCAN`；115200，行尾 `\n`。也可用 pyserial/PuTTY 直接驱动
- 用途：刷 SPI Flash（W25Q/MX25L/GD25Q，救路由器和主板 BIOS）、I²C EEPROM、AVR UPDI、锁死的 STM32
- 关键点：**它不需要目标芯片有串口或 bootloader**，直接对引脚打时序。SPI 最高 80MHz，比 CH341A 快几十倍
- 汉化版已镜像到站点：`fixpro/index.html`

### MioLink（自编译）
- 文件：`MioLink_v1.0_rp2040.uf2`　979 KB（Flash 占用 489KB）
- 协议：JTAG + SWD + SWO + RTT（Black Magic Probe 的 RP2040 移植）
- USB：`1D50:6018`（原版 BMP 厂商号）+ 两个串口（一个 GDB 传输，一个目标串口）
- 工具：`arm-none-eabi-gdb` 或 OpenOCD。**pyOCD 认不出它**，因为它模拟的是 GDB server 不是 CMSIS-DAP
- 用途：JTAG 菊花链、老 ARM7/ARM9、无 SWD 的芯片、SWO/RTT 实时打印
- 编译要点见 `references/rp2040-uf2.md` 末尾

### pico-uart-bridge
- 版本：v5.0　文件：`uart-bridge-pico.uf2`　63 KB
- 纯 USB-TTL 桥，无调试功能
- 双串口：串口0 = GP16(TX)/GP17(RX)，串口1 = GP4(TX)/GP5(RX)
- 电平 3.3V，接 5V 老设备需电平转换或确认对方能接受
- 用途：替代 CH340/CP2102，比那些模块稳定

## 不能用于 RP2040

- `debugprobe_on_pico2.uf2` — `family 0xE48BFF59`，是 RP2350（Pico 2）专用。RP2040 的 ROM bootloader 会逐块检查 family ID，不匹配就整块跳过，表现是盘符一直在、文件也拷完了，但什么都没发生。**不是「可能不兼容」，是确定装不进去。**
