"""生成一个最小闪灯固件 blink.bin：PC13（板载）与 PB0（外挂）反相闪烁。

用途：手头没有任何 hex 时，用它验证「烧录链路 + 芯片」是否真的通。

依赖 keystone-engine。运行后在当前目录得到 blink.bin，再用 flash.py 烧进去。
"""
import struct
import sys

try:
    from keystone import Ks, KS_ARCH_ARM, KS_MODE_THUMB
except ImportError:
    print("需要 keystone-engine：pip install keystone-engine")
    sys.exit(2)

# PC13 低电平点亮（板载），PB0 高电平点亮（外挂），故两者电平反相、视觉同步
ASM = """
    movw r0, #0x1018
    movt r0, #0x4002
    ldr  r1, [r0]
    orrs r1, r1, #0x18
    str  r1, [r0]

    movw r0, #0x1004
    movt r0, #0x4001
    movw r1, #0x4444
    movt r1, #0x4424
    str  r1, [r0]

    movw r0, #0x0c00
    movt r0, #0x4001
    movw r1, #0x4442
    movt r1, #0x4444
    str  r1, [r0]

loop:
    movw r2, #0x1010
    movt r2, #0x4001
    movw r5, #0x0c10
    movt r5, #0x4001

    movs r3, #1
    lsls r3, r3, #13
    str  r3, [r2]
    movs r6, #1
    lsls r6, r6, #16
    str  r6, [r5]
    bl   delay

    movs r3, #1
    lsls r3, r3, #29
    str  r3, [r2]
    movs r6, #1
    str  r6, [r5]
    bl   delay
    b    loop

delay:
    movw r4, #0x0000
    movt r4, #0x0002
dly:
    subs r4, r4, #1
    bne  dly
    bx   lr
"""

CODE_ADDR = 0x08000040
SP_INIT = 0x20005000

ks = Ks(KS_ARCH_ARM, KS_MODE_THUMB)
encoding, count = ks.asm(ASM, CODE_ADDR)

vectors = [SP_INIT] + [CODE_ADDR + 1] * 15
table = b"".join(struct.pack("<I", v) for v in vectors)
assert len(table) == 64

image = table + bytes(encoding)
while len(image) % 4:
    image += b"\x00"

with open("blink.bin", "wb") as f:
    f.write(image)

print(f"汇编指令 {count} 条，固件 {len(image)} 字节 → blink.bin")
print("烧录：python flash.py blink.bin")
