"""按 128KB / 1KB 页 的参数烧录 STM32F103 兼容片，并在烧完后回读校验。

用法：
    python flash.py app.hex
    python flash.py app.bin --addr 0x08000000
    python flash.py app.bin --no-erase      # 不整片擦，只擦要写到的页
"""
import argparse
import os
import sys

from pyocd.core.helpers import ConnectHelper
from pyocd.core.memory_map import MemoryMap, FlashRegion, RamRegion
from pyocd.target.builtin.target_STM32F103RC import FLASH_ALGO
from pyocd.coresight.coresight_target import CoreSightTarget
from pyocd.flash.file_programmer import FileProgrammer
from pyocd.flash.eraser import FlashEraser
import pyocd.target.builtin as builtin
import pyocd.target as _target_mod

FLASH_START = 0x08000000
FLASH_SIZE = 0x20000   # 兼容片实测 128KB（正品 C8 为 64KB）
PAGE_SIZE = 0x400      # 实测 1KB 页


class STM32F103CB(CoreSightTarget):
    VENDOR = "STMicroelectronics"
    MEMORY_MAP = MemoryMap(
        FlashRegion(start=FLASH_START, length=FLASH_SIZE, blocksize=PAGE_SIZE,
                    is_boot_memory=True, algo=FLASH_ALGO),
        RamRegion(start=0x20000000, length=0x5000),
    )

    def __init__(self, session):
        super().__init__(session, self.MEMORY_MAP)


builtin.BUILTIN_TARGETS["stm32f103cb"] = STM32F103CB
_target_mod.TARGET["stm32f103cb"] = STM32F103CB


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file", help="要烧的 .hex 或 .bin")
    ap.add_argument("--addr", type=lambda x: int(x, 0), default=FLASH_START,
                    help="bin 的起始地址，默认 0x08000000")
    ap.add_argument("--no-erase", action="store_true", help="跳过全片擦除")
    ap.add_argument("--freq", type=int, default=1000000)
    args = ap.parse_args()

    if not os.path.exists(args.file):
        print(f"文件不存在: {args.file}")
        return 2

    with ConnectHelper.session_with_chosen_probe(
            target_override="stm32f103cb", connect_mode="halt",
            options={"frequency": args.freq}) as s:
        t = s.target
        region = t.memory_map.get_boot_memory()
        print(f"芯片    : {t.part_number}")
        print(f"Flash   : 0x{region.start:08X}  {region.length // 1024}KB  页 {region.blocksize} 字节")

        if not args.no_erase:
            print("\n[1/3] 全片擦除…")
            FlashEraser(s, FlashEraser.Mode.CHIP).erase()
            print("  完成")

        print("\n[2/3] 写入…")
        FileProgrammer(s).program(args.file, base_address=args.addr)
        size = os.path.getsize(args.file)
        print(f"  {args.file}（{size} 字节）")

        print("\n[3/3] 回读校验…")
        if args.file.lower().endswith(".bin"):
            data = open(args.file, "rb").read()
            back = bytes(t.read_memory_block8(args.addr, len(data)))
            if back == data:
                print("  校验通过")
            else:
                print("  校验失败！")
                for i, (a, b) in enumerate(zip(data, back)):
                    if a != b:
                        print(f"    首个差异 偏移 0x{i:X}: 期望 {a:02X} 实际 {b:02X}")
                        break
                return 1
        else:
            print("  hex 由 FileProgrammer 内部校验，跳过逐字节比对")

        print("\n复位并运行…")
        t.reset()
        t.resume()
        print("完成")
        return 0


if __name__ == "__main__":
    sys.exit(main())
