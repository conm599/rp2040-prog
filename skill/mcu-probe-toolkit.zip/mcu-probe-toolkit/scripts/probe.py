"""读取 SWD 目标芯片的关键寄存器，判断芯片死活与型号特征。

用法：
    python probe.py                 # 自动选第一个探针
    python probe.py --uid-region    # 额外扫描 UID 周边地址，判断是否实现
"""
import argparse
import sys

from pyocd.core.helpers import ConnectHelper
from pyocd.core.memory_map import MemoryMap, FlashRegion, RamRegion
from pyocd.target.builtin.target_STM32F103RC import FLASH_ALGO
from pyocd.coresight.coresight_target import CoreSightTarget
import pyocd.target.builtin as builtin
import pyocd.target as _target_mod

FLASH_START = 0x08000000
FLASH_SIZE = 0x20000   # 兼容片实测 128KB
PAGE_SIZE = 0x400      # 实测 1KB 页


class STM32F103CB(CoreSightTarget):
    """F103 兼容片：128KB Flash / 1KB 页。ST 官方 F103C8 定义是 64KB，对不上会校验失败。"""
    VENDOR = "STMicroelectronics"
    MEMORY_MAP = MemoryMap(
        FlashRegion(start=FLASH_START, length=FLASH_SIZE, blocksize=PAGE_SIZE,
                    is_boot_memory=True, algo=FLASH_ALGO),
        RamRegion(start=0x20000000, length=0x5000),
    )

    def __init__(self, session):
        super().__init__(session, self.MEMORY_MAP)


builtin.BUILTIN_TARGETS["stm32f103cb"] = STM32F103CB
_target_mod.TARGET["stm32f103cb"] = STM32F103CB


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uid-region", action="store_true", help="扫描 0x1FFFF7xx 区段")
    ap.add_argument("--freq", type=int, default=1000000, help="SWD 频率 Hz，连不上时降到 100000")
    args = ap.parse_args()

    with ConnectHelper.session_with_chosen_probe(
            target_override="stm32f103cb", options={"frequency": args.freq}) as s:
        t = s.target
        try:
            t.halt()
        except Exception as e:
            print(f"HALT 失败: {e}")
            print("SWD 链路可能不通：检查 GND 共地、目标供电、SWCLK/SWDIO 是否接反、降频重试")
            return 2

        # pyOCD 不同版本 dpidr 可能是 int 或 DPIDR 对象（带 idr 属性）
        _d = t.dp.dpidr
        dpidr = getattr(_d, "idr", _d)
        dpidr = int(dpidr)
        print(f"DPIDR   : 0x{dpidr:08X}"
              + ("   (0x1BA01477 = 标准 SWD 端口，链路正常)"
                 if dpidr == 0x1BA01477 else "   (非标准值)"))
        print(f"CPUID   : 0x{t.read32(0xE000ED00):08X}")
        print(f"核心状态: {t.get_state()}")

        def rd32(a):
            try:
                return t.read32(a)
            except Exception:
                return None

        dbg = rd32(0xE0042000)
        if dbg is not None:
            print(f"DBGMCU  : 0x{dbg:08X}   DEV_ID=0x{(dbg >> 16) & 0xFFF:03X} "
                  f"REV_ID=0x{dbg & 0xFFFF:04X}")

        cap = rd32(0x1FFFF7E0)
        if cap is not None:
            kb = cap & 0xFFFF
            print(f"Flash   : {kb} KB" + ("   ← 标称 C8T6 应为 64，说明是兼容片" if kb == 128 else ""))

        uid = [rd32(0x1FFFF7E8 + 4 * i) for i in range(3)]
        if all(v == 0 for v in uid):
            print("UID     : 全 0（芯片未实现唯一 ID，非正品特征）")
        elif any(v is None for v in uid):
            print("UID     : 读取失败")
        else:
            print("UID     : " + "-".join(f"{v:08X}" for v in uid))

        if args.uid_region:
            print("\n--- 0x1FFFF7xx 区段扫描 ---")
            for a in range(0x1FFFF7D0, 0x1FFFF7FC, 4):
                v = rd32(a)
                note = ""
                if a == 0x1FFFF7E0:
                    note = " ← Flash 容量寄存器"
                elif a == 0x1FFFF7E8:
                    note = " ← UID 起始"
                print(f"0x{a:08X}  " + (f"0x{v:08X}" if v is not None else "读失败") + note)
            print("判定：容量寄存器有真实值、相邻地址为 FF、UID 段为 0 → 芯片确实没实现 UID，"
                  "不是读取路径问题")

        first = rd32(FLASH_START)
        if first is not None:
            print(f"\nFlash 首字: 0x{first:08X}  (0x2000xxxx 表示有固件；0xFFFFFFFF 表示空白)")

        t.resume()
        print("\n已恢复运行")
        return 0


if __name__ == "__main__":
    sys.exit(main())
